import WellSwapGlobalPlatform from '../components/WellSwapComplete';

export default function Home() {
  return <WellSwapGlobalPlatform />;
}